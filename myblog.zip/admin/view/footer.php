</div>
    </div>
</body>
<script src="./view/js/main.js"></script>
<script src="./ckeditor/ckeditor.js"></script>
<script>
    CKEDITOR.replace('content_post');
</script>
</html>