let btnChange = document.querySelector('.change_info'),
    infoPersonal = document.querySelector('.info_personal'),
    updateInfo = document.querySelector('.update_information');
btnChange.addEventListener('click', function() {
    infoPersonal.classList.remove('active');
    updateInfo.classList.toggle('active');
})